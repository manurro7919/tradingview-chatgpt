# TradingView + ChatGPT MVP

Este paquete está preparado para que otra persona te lo suba a Render o Railway y luego lo conecte a un GPT personalizado.

## Qué hace
- Recibe alertas de TradingView por webhook
- Guarda las alertas
- Expone endpoints para que un GPT las consulte
- Incluye un endpoint especial para tu cartera española

## 1) Cómo arrancarlo en local
```bash
pip install -r requirements.txt
export WEBHOOK_SECRET="tu-clave-larga"
uvicorn main:app --host 0.0.0.0 --port 8000
```

En Windows PowerShell:
```powershell
pip install -r requirements.txt
$env:WEBHOOK_SECRET="tu-clave-larga"
uvicorn main:app --host 0.0.0.0 --port 8000
```

## 2) Qué subir a Render
Sube estos archivos:
- main.py
- requirements.txt
- openapi.yaml
- .env.example

Comando de arranque:
```bash
uvicorn main:app --host 0.0.0.0 --port 10000
```

Variable de entorno:
- WEBHOOK_SECRET = una clave privada larga

## 3) URL del webhook en TradingView
Cuando Render te dé una URL pública, en TradingView pones:

```text
https://TU-DOMINIO.onrender.com/tradingview/alert
```

## 4) Mensaje JSON recomendado para TradingView
Pega esto en el campo Message de la alerta:

```json
{
  "secret": "TU_MISMA_CLAVE_PRIVADA",
  "ticker": "BME:SAN",
  "price": {{close}},
  "volume": {{volume}},
  "timeframe": "1D",
  "signal": "ruptura_resistencia",
  "quality": "alta",
  "timestamp": "{{timenow}}"
}
```

También puedes cambiar el ticker y la señal para BBVA, Iberdrola, etc.

## 5) Cómo conectarlo al GPT
En el constructor de tu GPT:
- Ve a Actions
- Crea una nueva Action
- Pega el contenido de openapi.yaml
- Cambia `https://TU-DOMINIO.com` por la URL real
- Guarda

## 6) Endpoints disponibles
- GET /alerts/today
- GET /alerts/{ticker}
- GET /signals/best
- GET /portfolio/signals

## 7) Limitación importante
Yo no puedo hacer por ti desde aquí estas acciones externas:
- entrar en tu cuenta de TradingView
- entrar en tu cuenta de ChatGPT para configurar el GPT
- desplegar el servidor en Render/Railway
- mantener el sistema en internet

Pero este paquete deja la parte técnica preparada para que tú o alguien te lo monte.
